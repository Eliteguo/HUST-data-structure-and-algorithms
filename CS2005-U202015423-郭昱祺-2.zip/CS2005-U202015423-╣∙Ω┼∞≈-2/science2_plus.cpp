#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
#define INFEASIBLE -1
#define OVERFLOW -2

typedef int status;
typedef int ElemType;  //����Ԫ�����Ͷ���

#define LIST_INIT_SIZE 100
#define LISTINCREMENT  20
typedef int ElemType;
typedef struct LNode{  //����������ʽ�ṹ�����Ķ���
      ElemType data;
      struct LNode *next;
    }LNode,*LinkList;

typedef struct//���Ա��Ĺ���������
{
    struct
    {
        char name[30];
        // LNode node;
        LinkList L;
    }elem[20];
    int length;
    int listsize;
}LISTS;

int op=1,op1=1,op2=1,op22=1,op3=1;
int judge=0,check=0,l,temp=0;
int listchange=1,point=1,kong=0;

status InitList(LinkList &L)
// ���Ա�L�����ڣ�����һ���յ����Ա�������OK�����򷵻�INFEASIBLE��
{
    /********** Begin *********/
    if(L!=NULL)
    return INFEASIBLE;
    L=(LNode*)malloc(sizeof(LNode));
    L->next=NULL;
    return OK;
    /********** End **********/
}
status DestroyList(LinkList &L)
// ������Ա�L���ڣ��������Ա�L���ͷ�����Ԫ�صĿռ䣬����OK�����򷵻�INFEASIBLE��
{
    if(L==NULL)
    return INFEASIBLE;
    LinkList p,temp=L;
    while(temp)
    {
        p=temp->next;
        free(temp);
        temp=p;
    }
    L=NULL;
    return OK;
}
status ClearList(LinkList &L)
{
    if(L==NULL)
    return INFEASIBLE;
    LinkList p,temp=L->next;
    while(temp)
    {
        p=temp->next;
        free(temp);
        temp=p;
    }
    L->next=NULL;
    return OK;
}
status ListEmpty(LinkList L)
{
    /********** Begin *********/
    if(L==NULL)
    return INFEASIBLE;
    else if(L->next==NULL)
    return TRUE;
    else
    return FALSE;
    /********** End **********/
}
int ListLength(LinkList L)
{
    /********** Begin *********/
    if(L==NULL)
    return INFEASIBLE;
    else
    {
        int i=0;
        while(L->next)
        {
            i++;
            L=L->next;
        }
        return i;
    }

    /********** End **********/
}
status GetElem(LinkList L,int i,ElemType &e)
{
    /********** Begin *********/
    if(L==NULL)
    return INFEASIBLE;
    else
    {
        LinkList temp=L->next;
        int length=0;
        while(temp)
        {
            length++;
            temp=temp->next;
        }
        if(i<1||i>length)
        return ERROR;
        else
        {
            for(int m=0;m<i;m++)
            L=L->next;
            e=L->data;
            return OK;
        }
    }
    /********** End **********/
}
status LocateElem(LinkList L,ElemType e)
{
    /********** Begin *********/
    if(L==NULL)
    return INFEASIBLE;
    int i=1;
    L=L->next;
    while(L)
    {
        if(L->data==e)
        return i;
        L=L->next;
        i++;
    }
    return  ERROR;
    /********** End **********/
}
status PriorElem(LinkList L,ElemType e,ElemType &pre)
{
    /********** Begin *********/
    if(L==NULL)
    return INFEASIBLE;
    LinkList prior=L;
    LinkList temp=L;
    L=prior->next;
    while(L)
    {
        if(L->data==e&&prior!=temp)
        {
            pre=prior->data;
            return OK;
        }
        L=L->next;
        prior=prior->next;
    }
    return ERROR;
    /********** End **********/
}
status NextElem(LinkList L,ElemType e,ElemType &next)
{
    /********** Begin *********/
    if(L==NULL)
    return INFEASIBLE;
    LinkList successor=L->next;
    while(successor)
    {
        if(L->data==e)
        {
            next=successor->data;
            return OK;
        }
        L=L->next;
        successor=successor->next;
    }
    return ERROR;

    /********** End **********/
}
status ListInsert(LinkList &L,int i,ElemType e)
{
    /********** Begin *********/
    if(L==NULL)
    return INFEASIBLE;
    LinkList insert=(LNode*)malloc(sizeof(LNode));
    LinkList temp,prior;
    temp=L->next;
    prior=L;
    if(i<1)
    return ERROR;
    for(int tmp=1;tmp<i;tmp++)
    {
        temp=temp->next;
        prior=prior->next;
        if(prior==NULL)
        return ERROR;
        if(prior!=NULL&&temp==NULL&&tmp!=i-1)
        return ERROR;
    }
    insert->data=e;
    insert->next=temp;
    prior->next=insert;
    return OK;
    /********** End **********/
}
status ListDelete(LinkList &L,int i,ElemType &e)
{
    /********** Begin *********/
    if(L==NULL)
    return INFEASIBLE;
    LinkList temp=L->next,prior=L;
    if(i<1)
    return ERROR;
    for(int tmp=1;tmp<i;tmp++)
    {
        temp=temp->next;
        prior=prior->next;
        if(temp==NULL)
        return ERROR;
    }
    prior->next=temp->next;
    e=temp->data;
    free(temp);
    return OK;
    /********** End **********/
}
status ListTraverse(LinkList L)
{
    /********** Begin *********/
    if(L==NULL)
    return INFEASIBLE;
    L=L->next;
    while(L)
    {
        printf("%d ",L->data);
        L=L->next;
    }
    return OK;
    /********** End **********/
}
status SaveList(LinkList L,char FileName[])
{
    /********** Begin 1 *********/
    if(L==NULL)
        return INFEASIBLE;
    else
    {
        FILE *fp;
        fp=fopen(FileName,"w");
        int i;
        if(fp==NULL)
        return ERROR;
        L=L->next;
        while(L)
        {
            fprintf(fp,"%d ",L->data);
            L=L->next;
        }
        fclose(fp);
        return OK;
    }
    /********** End 1 **********/
}
status LoadList(LinkList &L,char FileName[])
{
    /********** Begin 2 *********/
    if(L!=NULL)
        return INFEASIBLE;
    else
    {
        LinkList index,temp,check;
        L=(LNode *) malloc(sizeof(LNode));
        L->next=NULL;
        temp=L;
        index=temp->next;
        FILE *fp;
        fp=fopen(FileName,"r");
        if(fp==NULL)
        return -1;
        while(!feof(fp))
        {
            index=(LNode *) malloc(sizeof(LNode));
            fscanf(fp,"%d",&index->data);
            temp->next=index;
            index->next=NULL;
            index=index->next;
            temp=temp->next;
        }
        check=L;
        while(check->next!=temp)
        check=check->next;
        check->next=NULL;
        fclose(fp);
        return OK;
    }
    /********** End 2 **********/
}

void AddList(LISTS &Lists,char ListName[])
{
    /********** Begin *********/
    int temp=Lists.length+kong;
    strcpy(Lists.elem[temp].name,ListName);
    Lists.elem[temp].L=(LNode*) malloc(sizeof(LNode));
    Lists.elem[temp].L->next=NULL;
    Lists.length++;
    /********** End **********/
}
int LocateList(LISTS Lists,char ListName[])
{
    int i,j=1;
    for(i=0;i<Lists.length+kong;i++)
    {
        j=strcmp(ListName,Lists.elem[i].name);
        if(j==0)
            return i+1;
    }
    return 0;
}
int switchList(LISTS Lists,char ListName[])
{
    int temp;
    temp=LocateList(Lists,ListName);
    return temp;
}
void travel_lists(LISTS Lists)
{
    if(Lists.length==0)
    printf("There is no list in List manager\n");
    else
    {
        int temp=kong;
        int num=1;
        printf("    the lists in List manager are:\n");
        for(int k=1;k<=Lists.length+temp;)
        {
            if(Lists.elem[k-1].L != NULL)
            {
                printf("\n");
                printf("    [%d] %s\n",num,Lists.elem[k-1].name);
                k++;
                num++;
            } 
            else 
            {
                k++;
            }
        }
    }
}

status RemoveList(LISTS &Lists,char ListName[])
{
    int i,j,k,l;
    for(i=0;i<Lists.length;i++)
    {
        j=strcmp(ListName,Lists.elem[i].name);
        if(j==0)
        {
            DestroyList(Lists.elem[i].L);
            Lists.elem[i].name[0]={'\0'};
            Lists.length--;
            kong++;
            return OK;
        }
    }
    return ERROR;
}
void menu1(LinkList &L)
{
    op1=1;
    while(op1)
    {
        
        system("cls");	printf("\n\n");
        printf("                  Menu 1 Single List \n");
        printf("-------------------------------------------------\n");
        printf("*                                               *\n");
        printf("*    	  1. InitList       7. LocateElem       *\n");
        printf("*                                               *\n");
        printf("*    	  2. DestroyList    8. PriorElem        *\n");
        printf("*                                               *\n");
        printf("*    	  3. ClearList      9. NextElem         *\n");
        printf("*                                               *\n");
        printf("*    	  4. ListEmpty      10. ListInsert      *\n");
        printf("*                                               *\n");
        printf("*    	  5. ListLength     11. ListDelete      *\n");
        printf("*                                               *\n");
        printf("*    	  6. GetElem        12. ListTraverse    *\n");
        printf("*                                               *\n");
        printf("*    	  0. Exit                               *\n");
        printf("*                                               *\n");
        printf("-------------------------------------------------\n");
        printf("    Choose your operation and end of enter: ");
        fflush(stdin);
        scanf("%d",&op1);
        switch(op1){
        case 1:
            if(InitList(L)==OK)
            printf("���Ա������ɹ���\n");
            else printf("���Ա�����ʧ�ܣ�\n");
            getchar();getchar();
            break;
        case 2:
            judge=0,check=0;
            printf("ȷ��ɾ�����Ա���\n");
            printf("������ 1����  2����\n");
            scanf("%d",&judge);
            if(judge==1)
            {
                check=DestroyList(L);
                if(check==1)
                printf("���Ա���ɾ����");
                else
                printf("���Ա�δ�ɹ�ɾ����");
            }
            getchar();getchar();
            break;
        case 3:
            check=0;
            judge=0;
            printf("ȷ��������Ա���\n");
            printf("������ 1����  2����\n");
            scanf("%d",&judge);
            if(judge==OK)
            {
                check=ClearList(L);
                if(check==1)
                printf("���Ա�����գ�\n");
                else
                printf("���Ա�δ�ɹ���գ�\n");
            }
            getchar();getchar();
            break;
        case 4:
            check=0;
            check=ListEmpty(L);
            if(check==INFEASIBLE)
            printf("���Ա�Ϊ��\n");
            else if(check==TRUE)
            printf("���Ա�����Ϊ0\n");
            else if(check==FALSE)
            printf("���Ա����Ȳ�Ϊ0\n");
            getchar();getchar();
            break;
        case 5:
            int length;
            length=ListLength(L);
            if(length==INFEASIBLE)  
            printf("���Ա�L������\n");
            else
            printf("���Ա�����Ϊ%d\n",length);
            getchar();getchar();
            break;
        case 6:
            int i,e;
            check=0;
            printf("������Ԫ���߼�λ��i: ");
            scanf("%d",&i);
            check=GetElem(L,i,e);
            if(check==ERROR)
            printf("����ֵ�������Ա���Χ\n");
            else if(check==OK)
            printf("���Ա���%d��Ԫ��Ϊ%d\n",i,e);
            getchar();getchar();
            break;
        case 7:
            check=0;
            printf("����������ҵ�Ԫ��e: ");
            scanf("%d",&e);
            check=LocateElem(L,e);
            if(check==INFEASIBLE)
            printf("���Ա�L������\n");
            else if(check==ERROR)
            printf("����ʧ��\n");
            else
            printf("Ԫ�ص�һ�γ��ֵ��߼����Ϊ%d\n",check);
            getchar();getchar();
            break;
        case 8:
            int pre;
            check=0;
            printf("�����������ǰ����Ԫ��e: ");
            scanf("%d",&e);
            check=PriorElem(L,e,pre);
            if(check==INFEASIBLE)
            printf("���Ա�L������\n");
            else if(check==ERROR)
            printf("����ʧ��\n");
            else if(check==OK)
            printf("���Ա�Ԫ��eǰ��Ϊ:%d\n",pre);
            getchar();getchar();
            break;
        case 9:
            int next;
            check=0;
            printf("����������Һ�����Ԫ��e: ");
            scanf("%d",&e);
            check=NextElem(L,e,next);
            if(check==INFEASIBLE)
            printf("���Ա�L������\n");
            else if(check==ERROR)
            printf("����ʧ��\n");
            else if(check==OK)
            printf("���Ա�Ԫ��e����Ϊ:%d\n",next);
            getchar();getchar();
            break;
        case 10:
            check=0;
            printf("�����������Ԫ�ص�λ��i: ");
            scanf("%d",&i);
            printf("��������Ҫ�����Ԫ�أ�");
            scanf("%d",&e);
            check=ListInsert(L,i,e);  
            if(check==ERROR)  
            printf("����ʧ��\n");
            else if(check==OK)
            printf("����ɹ�\n");
            getchar();getchar();
            break;
        case 11:
            check=0;
            printf("��������ɾ����Ԫ�ص��߼����: ");
            scanf("%d",&i);
            check=ListDelete(L,i,e);
            if(check==INFEASIBLE)
            printf("���Ա�L������\n");
            else if(check==ERROR)
            printf("ɾ��ʧ��\n");
            else if(check==OK)
            printf("ɾ���ĵ�%d��Ԫ��Ϊ%d",i,e);
            getchar();getchar();
            break;
        case 12:  
            check=ListTraverse(L);
            if(check==-1) 
            printf("���Ա������ڣ�\n");
            getchar();getchar();
            break;
        case 0:
            break;
        default:
            printf("    ����ȷ���룡\n");
            system("pause");
            break;
        }//end of switch
    }//end of while
    printf("����������һ���˵���\n");
    system("pause");
}
void menu2_under(LinkList &L)
{
    char str1[100];
    op22=1;
    while(op22)
    {
        
        system("cls");	printf("\n\n");
        printf("            Under Menu 2 List operation          \n");
        printf("-------------------------------------------------\n");
        printf("*                                               *\n");
        printf("*    	  1. InitList       7. LocateElem       *\n");
        printf("*                                               *\n");
        printf("*    	  2. DestroyList    8. PriorElem        *\n");
        printf("*                                               *\n");
        printf("*    	  3. ClearList      9. NextElem         *\n");
        printf("*                                               *\n");
        printf("*    	  4. ListEmpty      10. ListInsert      *\n");
        printf("*                                               *\n");
        printf("*    	  5. ListLength     11. ListDelete      *\n");
        printf("*                                               *\n");
        printf("*    	  6. GetElem        12. ListTraverse    *\n");
        printf("*                                               *\n");
        printf("*    	  0. Exit                               *\n");
        printf("*                                               *\n");
        printf("-------------------------------------------------\n");
        printf("    Choose your operation and end of enter: ");
        fflush(stdin);
        scanf("%d",&op22);
        switch(op22){
        case 1:
            if(InitList(L)==OK)
            printf("���Ա������ɹ���\n");
            else printf("���Ա�����ʧ�ܣ�\n");
            getchar();getchar();
            break;
        case 2:
            judge=0,check=0;
            printf("ȷ��ɾ�����Ա���\n");
            printf("������ 1����  2����\n");
            scanf("%d",&judge);
            if(judge==1)
            {
                check=DestroyList(L);
                if(check==1)
                printf("���Ա���ɾ����");
                else
                printf("���Ա�δ�ɹ�ɾ����");
            }
            getchar();getchar();
            break;
        case 3:
            check=0;
            judge=0;
            printf("ȷ��������Ա���\n");
            printf("������ 1����  2����\n");
            scanf("%d",&judge);
            if(judge==OK)
            {
                check=ClearList(L);
                if(check==1)
                printf("���Ա�����գ�\n");
                else
                printf("���Ա�δ�ɹ���գ�\n");
            }
            getchar();getchar();
            break;
        case 4:
            check=0;
            check=ListEmpty(L);
            if(check==INFEASIBLE)
            printf("���Ա�Ϊ��\n");
            else if(check==TRUE)
            printf("���Ա�����Ϊ0\n");
            else if(check==FALSE)
            printf("���Ա����Ȳ�Ϊ0\n");
            getchar();getchar();
            break;
        case 5:
            int length;
            length=ListLength(L);
            if(length==INFEASIBLE)  
            printf("���Ա�L������\n");
            else
            printf("���Ա�����Ϊ%d\n",length);
            getchar();getchar();
            break;
        case 6:
            int i,e;
            check=0;
            printf("������Ԫ���߼�λ��i: ");
            scanf("%d",&i);
            check=GetElem(L,i,e);
            if(check==ERROR)
            printf("����ֵ�������Ա���Χ\n");
            else if(check==OK)
            printf("���Ա���i��Ԫ��Ϊ%d\n",e);
            getchar();getchar();
            break;
        case 7:
            check=0;
            printf("����������ҵ�Ԫ��e: ");
            scanf("%d",&e);
            check=LocateElem(L,e);
            if(check==INFEASIBLE)
            printf("���Ա�L������\n");
            else if(check==ERROR)
            printf("����ʧ��\n");
            else
            printf("Ԫ�ص�һ�γ��ֵ��߼����Ϊ%d\n",check);
            getchar();getchar();
            break;
        case 8:
            int pre;
            check=0;
            printf("�����������ǰ����Ԫ��e: ");
            scanf("%d",&e);
            check=PriorElem(L,e,pre);
            if(check==INFEASIBLE)
            printf("���Ա�L������\n");
            else if(check==ERROR)
            printf("����ʧ��\n");
            else if(check==OK)
            printf("���Ա�Ԫ��eǰ��Ϊ:%d\n",pre);
            getchar();getchar();
            break;
        case 9:
            int next;
            check=0;
            printf("����������Һ�����Ԫ��e: ");
            scanf("%d",&e);
            check=NextElem(L,e,next);
            if(check==INFEASIBLE)
            printf("���Ա�L������\n");
            else if(check==ERROR)
            printf("����ʧ��\n");
            else if(check==OK)
            printf("���Ա�Ԫ��e����Ϊ:%d\n",next);
            getchar();getchar();
            break;
        case 10:
            check=0;
            printf("�����������Ԫ�ص�λ��i: ");
            scanf("%d",&i);
            printf("��������Ҫ�����Ԫ�أ�");
            scanf("%d",&e);
            check=ListInsert(L,i,e);  
            if(check==ERROR)  
            printf("����ʧ��\n");
            else if(check==OK)
            printf("����ɹ�\n");
            getchar();getchar();
            break;
        case 11:
            check=0;
            printf("��������ɾ����Ԫ���߼����: ");
            scanf("%d",&i);
            check=ListDelete(L,i,e);
            if(check==INFEASIBLE)
            printf("���Ա�L������\n");
            else if(check==ERROR)
            printf("ɾ��ʧ��\n");
            else if(check==OK)
            printf("ɾ���ĵ�i��Ԫ��Ϊ%d",e);
            getchar();getchar();
            break;
        case 12:  
            check=ListTraverse(L);
            if(check==-1)
            printf("���Ա��ǿձ���\n");
            getchar();getchar();
            break;
        case 0:
            break;
        default:
            printf("    ����ȷ���룡\n");
            system("pause");
            break;
        }//end of switch
    }//end of while
    printf("����������һ���˵���\n");
    system("pause");
}
void menu2(LISTS &Lists)
{
    op2=1;
    while(op2)
    {
        char str1[100];
        system("cls");	printf("\n\n");
        printf("                  Menu 2 List manager                \n");
        printf("-----------------------------------------------------       \n");
        printf("*    	       1. AddList                           *        \n");
        printf("*                                                   *       \n");
        printf("*    	       2. DeleteList                        *        \n");
        printf("*                                                   *        \n");
        printf("*    	       3. switchList                        *        \n");
        printf("*                                                   *       \n");
        printf("*    	       4. Travel lists of List manager      *        \n");
        printf("*                                                   *       \n");
        printf("*    	       5. operate on Lists of List manager  *        \n");
        printf("*                                                   *       \n");
        printf("*    	       0. Exit                              *        \n");
        printf("*                                                   *       \n");
        printf("-----------------------------------------------------       \n");
        printf("    Choose your operation and end of enter: ");
        fflush(stdin);
        scanf("%d",&op2);
        switch (op2)
        {
            case 1:
                printf("������Ҫ���ӵ����Ա����ƣ�");
                scanf("%s",str1);
                AddList(Lists,str1);
                printf("�����������Ա�\n");
                system("pause");
                break;
            case 2:
                check=0;
                printf("������Ҫɾ�������Ա����ƣ�");
                scanf("%s",str1);
                check=RemoveList(Lists,str1);
                if(check==OK)
                printf("��ɾ������Ϊ%s�����Ա�\n",str1);
                else if(check==ERROR)
                printf("û�в��ҵ�����Ϊ%s�����Ա�\n",str1);
                system("pause");
                break;
            case 3:
                printf("������Ҫ�л������Ա����ƣ�");
                scanf("%s",str1);
                listchange=switchList(Lists,str1);
                if(listchange==0)
                printf("�����ڸ����Ա�\n");
                else
                printf("���Ա��л��ɹ�\n");
                system("pause");
                break;
            
            case 4:
                travel_lists(Lists);
                system("pause");
                break;
            case 5:
                menu2_under(Lists.elem[listchange-1].L);
                break;
            case 0:
                break;
            default:
                printf("    ����ȷ���룡\n");
                system("pause");
                break;
        }
    }
    printf("����������һ���˵���\n");
    system("pause");
}
void menu3_1(LinkList &L)
{
    op3=1;
    char FileName[100];
    while(op3)
    {
        system("cls");printf("\n\n");
        printf("                Menu 3 File operation                \n");
        printf("-----------------------------------------------------    \n");
        printf("*                                                   *    \n");
        printf("*    1. Scan the data of single list into file	    *    \n");
        printf("*                                                   *    \n");
        printf("*    2. Read the data of file into empty list  	    *    \n"); 
        printf("*                                                   *    \n");     
        printf("*    0. Exit                                        *    \n");  
        printf("*                                                   *    \n");
        printf("-----------------------------------------------------    \n");
        printf("    Choose your operation and end of enter: ");
        fflush(stdin);
        scanf("%d",&op3);
        switch (op3)
        {
        case 1:
            printf("��������Ҫд���FileName�ļ�����");
            scanf("%s",FileName);
            check=SaveList(L,FileName);
            if(check==-1)
            printf("���Ա�������!\n");
            else if(check==1)
            printf("�ѳɹ�д��%s�ļ��У�\n",FileName);
            system("pause");
            break;
        case 2:
            printf("��������Ҫ�����FileName�ļ�����");
            scanf("%s",FileName);
            check=LoadList(L,FileName);
            if(check==-1)
            printf("���Ա��Ѵ��ڣ����������룡\n");
            else if(check==-2)
            printf("��������Ӧ�ļ�\n");
            else if (check==1)
            printf("%s�ļ��е������ѳɹ����룡\n",FileName);
            system("pause");
            break;
        case 0:
            break;
        default:
                printf("    ����ȷ���룡\n");
                system("pause");
                break;
        }
    }
    printf("����������һ���˵���\n");
    system("pause");
}
void menu3_2(LISTS &Lists)
{
    op3=1;
    char FileName[100];
    char str1[100];
    while(op3)
    {
        system("cls");printf("\n\n");
        printf("                Menu 3 File operation                \n");
        printf("-----------------------------------------------------    \n");
        printf("*                                                   *    \n");
        printf("*    1. Scan the data of single list into file	    *    \n");
        printf("*                                                   *    \n");
        printf("*    2. Read the data of file into empty list  	    *    \n"); 
        printf("*                                                   *    \n");   
        printf("*    3. SwitchList                                  *     \n");
        printf("*                                                   *    \n");
        printf("*    4. DestroyList                                 *     \n");
        printf("*                                                   *    \n");
        printf("*    5. Check the list point now                    *    \n");
        printf("*                                                   *    \n");
        printf("*    0. Exit                                        *    \n");
        printf("*                                                   *    \n");
        printf("-----------------------------------------------------    \n");
        printf("    Choose your operation and end of enter: ");
        fflush(stdin);
        scanf("%d",&op3);
        switch (op3)
        {
        case 1:
            printf("��������Ҫд���FileName�ļ�����");
            scanf("%s",FileName);
            check=SaveList(Lists.elem[listchange-1].L,FileName);
            if(check==-1)
            printf("���Ա�%s������!\n",Lists.elem[listchange-1].name);
            else if(check==1)
            printf("���Ա�%s�ѳɹ�д��%s�ļ��У�\n",Lists.elem[listchange-1].name,FileName);
            system("pause");
            break;
        case 2:
            printf("��������Ҫ�����FileName�ļ�����");
            scanf("%s",FileName);
            check=LoadList(Lists.elem[Lists.length].L,FileName);
            if(check==-2)
            printf("��������Ӧ�ļ�\n");
            else if (check==1)
            {
                printf("please scan the name of the list: ");
                scanf("%s",Lists.elem[Lists.length].name);
                printf("%s�ļ��е������ѳɹ����룡\n",FileName);
                Lists.length++;
            }
            system("pause");
            break;
        case 3:
            printf("������Ҫ�л������Ա����ƣ�");
            scanf("%s",str1);
            listchange=switchList(Lists,str1);
            if(listchange==0)
            printf("�����ڸ����Ա�\n");
            else
            printf("���Ա��л��ɹ�\n");
            system("pause");
            break;
        case 4:
            check=0;
            printf("������Ҫɾ�������Ա����ƣ�");
            scanf("%s",str1);
            check=RemoveList(Lists,str1);
            if(check==OK)
            printf("��ɾ������Ϊ%s�����Ա�\n",str1);
            else if(check==ERROR)
            printf("û�в��ҵ�����Ϊ%s�����Ա�\n",str1);
            system("pause");
            break;
        case 5:
            printf("%d\n",listchange);
            system("pause");
            break;
        case 0:
            break;
        default:
                printf("    ����ȷ���룡\n");
                system("pause");
                break;
        }
    }
    printf("����������һ���˵���\n");
    system("pause");
}

int main()
{
    LinkList L;
    L=NULL;
    LISTS Lists;
    Lists.listsize=LISTINCREMENT;
    Lists.length=0;
    for(int i=0;i<LISTINCREMENT;i++)
    Lists.elem[i].L=NULL;
    while(op)
    {
        
        system("cls");
        printf("-------------------------------------------------    \n");
        printf("                    Main Menu                         \n");
        printf("-------------------------------------------------    \n");
        printf("*                                               *    \n");
        printf("*    	           1. Single List               *     \n");
        printf("*                                               *     \n");
        printf("*    	           2. List manager              *     \n");
        printf("*                                               *     \n");
        printf("*    	           3. File                      *     \n"); 
        printf("*                                               *     \n");      
        printf("*    	           0. Exit                      *     \n");
        printf("*                                               *     \n");
        printf("-------------------------------------------------    \n");
        printf("    Choose your operation and end of enter: ");
        fflush(stdin);
        scanf("%d",&op);
        switch (op)
        {
            case 1:
                op1=1;
                menu1(L);
                break;
            case 2:
                op2=1;
                menu2(Lists);
                break;
            case 3:
                printf("\n");
                printf("    please choose which kind of list do you want to operate:\n");
                printf("\n");
                printf("    1.single list 2.list of list manager\n");
                printf("\n");
                printf("    your choose : ");
                scanf("%d",&l);
                if(l==1)
                menu3_1(L);
                else if(l==2)
                menu3_2(Lists);
                break;
            case 0:
                break;
            default:
                 printf("    ����ȷ���룡\n");
                system("pause");
                break;
        }
    }
    printf("����������һ���˵���\n");
    system("pause");
}